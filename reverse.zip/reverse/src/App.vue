<template>
<div class="main">
    <div class="freenote">
        <h2 class="free">Freenote .</h2>
        <div class="new">
            <i class="fa fa-plus-circle plus"></i>
            <h4 class="newnote">新增筆記</h4></div>
        <div class="alltag">
            <i class="fa fa-file-text ui"></i>
            <p class="all oop">所有筆記</p>
            <i class="fa fa-star iconnote ui"></i>
            <p class="tag oop">捷徑</P>
            <i class="fa fa-tag icontest ui"></i>
            <p class="tag oop">標籤</p>
            <i class="fa fa-calendar iconnote ui"></i>
            <p class="tag oop">月曆</p>
            <i class="fa fa-user iconnote ui"></i>
            <p class="tag oop">與我共用</p>
            <i class="fa fa-trash iconnote ui"></i>
            <p class="tag oop">垃圾桶</p>
        </div>
        <div class="modecontainer">
        <p class="mode oop">模式</p>
        <i class="fa fa-certificate iconmode1"></i>
        <i class="fa fa-moon-o iconmode2"></i></div>
        <div class="">
        <img src="class=miso">
        <select name="who" class="who">
          <option value="">Miso</option>
        </select>
        </div> 
           
    </div>
    <div class="note">
        <div class="search">
            <img src="class=icon"> 
            <input type="text" placeholder="搜尋您的筆記" class="search2" />
        </div>
        <div class="select">
            <p class="allnote">所有筆記</p>
            <i class="fa fa-chevron-down www"></i>
            <i class="fa fa-th iconform"></i>
        </div>
       <hr width="400px" color="#E6E6E6" align="cener">
        <div class="square">
            <h3 class="kk">無標題</h3>
            <hr width="250px" color="#E6E6E6" align="cener">
            <p class="date">2019/9/7</p>
        </div>
    </div>
    <div>
      <div class="vvv">
        <div class="line">
        <p class="arial">Arial</p> 
        <i class="fa fa-angle-down rrr"></i>
        <p class="fff">14</p>
        <i class="fa fa-angle-down rrr"></i>
        <i class="fa fa-bold BBB"></i>
        <i class="fa fa-italic iii"></i>
        <i class="fa fa-underline uuu"></i>
        <i class="fa fa-indent yyy"></i>
        <i class="fa fa-outdent ooo"></i>
        <i class="fa fa-align-left sss"></i>
        <i class="fa fa-angle-down rrr"></i>
        <i class="fa fa-align-justify zzz"></i>
        <i class="fa fa-angle-down rrr"></i>
        <i class="fa fa-list-ul xxx"></i>
        <i class="fa fa-link lll"></i>
        <i class="fa fa-image mmm"></i>
        <i class="fa fa-paperclip jjj"></i>
        <hr width="500px" color="#E6E6E6" align="left">
        </div>  

        <p class="none">無標題</p> 
        <div class="addplus"><p class="word">Add +</p></div>
        <div class="write">請寫下內容</div>
        <div class="lastplus">
        <i class="fa fa-file doc"></i>
        <p class="upload">上傳檔案、圖片、音檔</p>
        <p class="click"><u>點擊上傳檔案</u></p>
        <i class="fa fa-plus qwe"></i>
        </div>
    </div>
    </div>
</div>
</template>

<script>

</script>


<style>

.main{
    width: 100%;
    height: 100%;
    display: flex;
}

.freenote{
    width: 256px;
    height: 850px;
    background-color:#2F419B;
    display: flex;
    flex-direction: column;
    align-items: center;
    
}
    .free{
        font-size: 22px;
        font-family: Myriad Pro,Semibold;
        color: #FFFFFF;
        margin: 54px 0px 33px 54px;
        align-self: flex-start;

    }

    .new{
        width: 190px;
        height: 48px;
        background-color: #FFFFFF;
        border-radius: 5px;
        margin: 0px 33px 0px 33px;
        display: flex; 
        align-self: flex-start;       
    }

        .plus{color: #2F419B;
           font-size:26px;
           margin: 12px 16px 0px 30px;
           /* text-align: center; */
          
           
        }

        .newnote{
            color: #2F419B;
            font-size: 18px;
            margin-top: 12px; 
        }

    .alltag{
        width: 190px;
        height: 450px;
        padding: 33px 0px 0px 33px;
        display: flex;
        flex-direction: column;
        
    }

  .oop{
      color: #FFFFFF;
      font-family: Helvetica Neue;
      font-weight: lighter;
      font-size: 16px;
      width: 64px;
      
    
  }

    .ui{
    color: #FFFFFF;
    width: 16px;
    margin: 0px;
    }

  .modecontainer{
    width: 190px;
    height: 32px;
    align-self: center;
    margin: 80px 0px 0px 0px;
  }

    .mode{
      margin: 0px 20px 5px 20px;
      display: inline;
      vertical-align: middle;
    }

    .iconmode1{
        color: #FFFFFF;
        font-size: 26px;
        margin: 0px 12px 0px 0px;
        vertical-align: middle;
    }

    .iconmode2{
        color: #FFFFFF;
        font-size: 26px;
        vertical-align: middle;
    }

    .who{
        width: 70px;
        height:35px;
        border: none;
        background: #2F419B;
        font-size: 18px;
        font-family: Helvetica Neue;
        color: #FFFFFF;
        margin-left: 6px;
    }


    

.note{
    background-color: #F4F6F7;
    display: flex;
    flex-wrap: nowrap;
    flex-direction: column;
    
}

    .search{
        width:290px;
        height: 45px;
        background-color: #E6E6E6;
        border-radius: 5px;
        float: left;
    }
    .select{
        width: 290px;
        height: 42px;
    }

        .allnote{
            font-family: Helvetica Neue;
            font-weight: bold;
            color: #555555;
            display: inline;
        }

        .www{
            color: #555555;
            font-size: 12px;
        }
        
        .iconform{
            color: #555555;
            font-size: 13px;
            margin: 0px;
        }

    .square{ 
        width: 290px;
        height: 255px;
        background-color: #FFFFFF;
        position: relative;
        background: linear-gradient(-150deg, transparent 1.5em, #FFFFFF 0);
        border-radius: .5em;
    }

    .square::before {
        content: '';
        position: absolute;
        top: 0;
        right: 0;
        background: linear-gradient(to left bottom, transparent 50%,  rgba(0,0,0,.2) 0,rgba(0,0,0,.2)) no-repeat 100% 0;
        width: 1.73em;
        height: 3em;
        transform: translateY(-1.3em) rotate(-30deg);
        transform-origin: bottom right;
        border-bottom-left-radius: inherit;
        box-shadow: -.2em .2em .3em -.1em rgba(0,0,0,.15);
    }


    .kk{
        color: #555555;
    }

    .date{
        color: #666666;
        font-size: 15px;
    }

.vvv{
   
    background-color: #FFFFFF;
    display: flex;
    flex-wrap: nowrap;
    flex-direction: column;
    
}

    .line{
        width: 567px;
        height: 24px;
    }


        .arial{
            font-size: 18px;
            font-family: Helvetica Neue;
            font-weight: medium;
            color: #666666;
            display: inline;
        }
        
        .rrr{
            font-size: 14px;
            color: #A3A3A3;
            display: inline;
        }

        .fff{
            font-size: 18px;
            font-family: Helvetica Neue;
            font-weight: bold;
            color: #666666;
            display: inline;
        }

        .BBB, .iii, .uuu, .yyy, .ooo, .sss, .zzz, .xxx, .lll, .mmm, .jjj
        {
            font-size: 16px;
            color: #666666; 
            display: inline;
        }

        .BBB{
            font-weight: bold;
        }


        .word{
            color:#A3A3A3; 
            font-size: 14px;
            margin: 0px;
            display: inline;
        }

        .addplus{
            width: 75px;
            height: 25px;
            border: 1px;
            border-color: #C7C7C7;
            border-style: dashed;
            border-radius: 3px;
            margin-left: 46px;
        }

        .none{
            font-size: 21px;
            color: #A3A3A3;
        }

        .write{
            width: 580px;
            height: 142px;
            font-size: 16px;
            color: #666666;
        }

        .lastplus{
            width:580px;
            height: 55px;
            border: 1px;
            border-color: #C7C7C7;
            border-style: dashed;
            border-radius: 5px;
        }

            .doc{
                font-size: 18px;
                color: #A3A3A3;
                display: inline-block;
            }

            .upload{
                font-size: 16px;
                color: #A3A3A3;
                display: inline;
            }
            
            .click{
                font-size: 16px;
                color: #A3A3A3;
                display: inline;
            }

            .qwe{
                font-size: 16px;
                color: #A3A3A3;
                float: right;
            }

</style>
