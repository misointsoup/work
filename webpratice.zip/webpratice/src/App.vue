<template>
  <div>
    <body>
<header>消失的文明
</header>
<nav class="navbar">
  <ul class="first">
    <li><a href="#">蘇美文明</a>
      <ul class="second">
        <li><a href="#">介紹</a></li>
        <li><a href="#">蘇美王表</a></li>
        <li><a href="#">地球編年史</a></li>
        <li><a href="#">未知與傳說</a></li>
       </ul>
    </li>
      <li><a href="#">瑪雅文明</a>
        <ul class="second">
          <li><a href="#">介紹</a></li>
          <li><a href="#">預言</a></li>
          <li><a href="#">未知與傳說</a></li>
        </ul>
      </li>
    <li><a href="#">亞特蘭帝斯</a>
      <ul class="second">
        <li><a href="#">介紹</a></li>
        <li><a href="#">未知與傳說</a></li>
        <li><a href="#">柏拉圖</a></li>
       </ul>
    </li>
     <li><a href="#">古奧爾梅克文明</a>
       <ul class="second">
         <li><a href="#">介紹</a></li>
         <li><a href="#">未知與傳說</a></li>
        </ul>
      </li>
      <li><a href="#">共同謎團</a>
        <ul class="second">
          <li><a href="#">經緯度</a></li>
          <li><a href="#">大洪水</a></li>
          <li><a href="#">神話</a></li>
         </ul>
      </li>
    </ul>
</nav>

<nav class="sidebar">未解之謎
  <ul class="first">
    <li><a href="#">遺跡</a>
      <ul class="second side">
        <li><a href="#">普瑪彭古</a></li>
        <li><a href="#">復活節巨石像</a></li>
        <li><a href="#">納斯卡線</a></li>
      </ul>
    </li>
    <li><a href="#">神話與科學</a></li>
    <li><a href="#">宇宙</a>
      <ul class="second side">
        <li><a href="#">外星人</a></li>
        <li><a href="#">維度</a></li>
      </ul>
    </li>
     <li><a href="#">靈魂</a>
       <ul class="second side">
         <li><a href="#">靈魂轉世案例</a></li>
         <li><a href="#">研究</a></li>
       </ul>
      </li>
     </ul>
    </nav>
  </body>
  </div>
</template>

<script>
</script>

<style>

</style>
