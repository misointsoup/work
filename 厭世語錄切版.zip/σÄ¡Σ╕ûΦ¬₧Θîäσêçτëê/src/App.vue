<template>
<div class="website">
  <div class="banner">
    <div class="container">
      <div class="text">
        <h1>人生就是要來點負能量</h1>
          <p>每天不是厭世就是更厭世</p>
        <h2>心靈雞湯有什麼好的</h2>
        <p>也沒有變得比較好<br>厭世真香<br>來一碗？
        </p>
      </div>
    </div>
  </div>
  <div class="hate">
    <div curse>
      <div class="cursebefore">我想打起精神來</div>
      <div class="courseafter">卻不小心把他打死了</div></div>
    <div class="curse">
      <div class="cursebefore">騎在白馬上的不一定是王子</div>
      <div class="curseafter">還可能是唐僧<br>來超渡你這妖孽</div></div>
  <div>看你的臉就知道感情路很順<br>一路上都沒人</div>
  <div>長得好看的才叫吃貨<br>不好看的那叫飯桶</div>
  <div>世上有99%的事可以靠錢解決<br>剩下的1%需要更多的錢</div>
  <div>好好活下去<br>每天都有新打擊</div>
  </div>

</div>
</template>

<script>

</script>

<style>

*{
  margin: 0px;
  padding: 0px;
}

*, *::before, *::after{
box-sizing: border-box;
}

img{
  max-width: 100%;
  height: auto;
}

.website{
  max-width: 1200px;
  height: 100vh;
  font-family: 'Noto Sans TC', sans-serif;
  display: flex;
  flex-direction: column;
  justify-content: center;
  align-items: center;
}

.curse{
  width: 300px;
  height: 300px;
  position: relative;
  box-sizing: border-box;
  perspective: 800px;  
  background-color: lightblue;
  display: flex;
}

.coursebefore{
  width: 100%;
  height: 100%;
  position: absolute;
  top:0;
  left: 0;
  backface-visibility: hidden;
  transition: 1s;
}

.curseafter{
  width: 100%;
  height: 100%;
  position: absolute;
  top:0;
  left: 0;
  color: #fff;
  background-color: pink;
  transform: rotateY(-180deg);
  backface-visibility: hidden;
  transition: 1s;
  display: flex;
  align-items: center;
  justify-content: center;
}

.curse:hover .cursebefore{
  transform: rotateY(180deg);
}

.curse:hover .curseafter{
  transform: rotateY(0deg);
}


</style>
