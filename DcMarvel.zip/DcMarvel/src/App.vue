<template>
<div>
<body>
 <header>
  DC與漫威
</header>
 <nav class="navbar">
  <ul class="first">
    <img src="./img/dcmarvel.jpg">
    <li><a href="#DC">DC介紹</a></li>
    <li><a href="#marvel">漫威介紹</a></li>
    <li><a href="#">DC角色</a>
      <ul class="second">
        <li><a href="#">蝙蝠俠</a></li>
        <li><a href="#">水行俠</a></li>
        <li><a href="#">閃電俠</a></li>
      </ul>
      </li>
     <li><a href="#">漫威角色</a>
      <ul class="second">
       <li><a href="#">奇異博士</a></li>
       <li><a href="#">黑寡婦</a></li>
       <li><a href="#">鋼鐵人</a></li>
      </ul>
      </li>
   <li><a href="#">特殊角色</a>
     <ul class="second">
      <li><a href="#">蜘蛛人</a></li>
      <li><a href="#">死侍</a></li>
      <li><a href="#">X戰警</a></li>
     </ul>
    </li>
   <li><a href="#">要反不反的反派</a>
     <ul class="second">
      <li><a href="#">洛基</a></li>
      <li><a href="#">薩諾斯</a></li>
      </ul>
    </li>
    <input type="text" name="Search" placeholder="Search">
    </ul>
  </nav>
<div class="text">
  <div class="sidebar">
    <ul class="sidefirst">
      <li><img src="./img/movie.png"><a href="#">索尼</a>
        <ul class="siedesecond">
          <li><a href="#">介紹</a></li>
          <li><a href="#">代表角色</a></li>
        </ul>
      </li>
      <li><img src="./img/movie.png"><a href="#">福斯</a>
        <ul class="siedesecond">
          <li><a href="#">介紹</a></li>
          <li><a href="#">代表角色</a></li>
        </ul>
      </li>
      <li><img src="./img/icons8-avengers-144.png"><a href="#">漫威影集</a></li>
      <li><img src="./img/dc-1.png"><a href="#">DC影集</a></li>
    </ul>
  </div>
  <img src="./img/deadpool.png" alt="deadpool">
  <img src="./img/spiderman.png" alt="spiderman">

   <div class="article">
    <h1>DC v.s 漫威</h1>
    <p>2020/10/08</p>

    <span class="vs"><h2>快速分辨DC與Marvel</h2>
    <h3>DC</h3>
      <li>屬於華納兄弟影業</li>
      <li>第一個超級英雄是DC在1933年創造的超人</li>
      <li>著名角色：超人、蝙蝠俠、神力女超人、水行俠、小丑、自殺突擊隊、正義聯盟.etc</li>
    
    <h3>漫威Marvel</h3> 
      <li>屬於迪士尼影業</li>
      <li>著名的英雄角色創作者，史丹利(Stan.Lee)為漫威之父</li>
      <li>著名角色：美國隊長、鋼鐵人、奇異博士、黑豹、黑寡婦、蟻人、復仇者聯盟.etc</li>
    </span>

    <hr>

    <span id="DC"><h2>DC簡介</h2>
    <p>DC漫畫公司（英語：DC Comics, Inc.）是一家美國漫畫書出版社，其名稱中的「DC」源自該公司著名漫畫系列書《偵探漫畫》（Detective Comics）的首字母縮寫，
      是華納兄弟娛樂公司旗下的出版事業單位，也是美國規模最大和資歷最深的漫畫出版社之一。<br/>
      DC漫畫世界中英雄/罪犯族群主要構成的都是人類，除外星人血統與來自神魔的加持外，
      DC世界存在著為數不少的英雄都是沒有任何超能力，單純靠後天的訓練與各樣裝備而成為超級英雄；
      最明顯的例子是蝙蝠俠家族與Green Arrow一脈。當然地球上存在著各種隱藏的種族如神奇女俠的Amazon族、潛水俠的Atlanteans族、
      Blood Tribe與Gorilla Grodd的智慧猿猴族等。
    </p>
    </span>
    <h2>DC宇宙</h2>
    <p>DC宇宙（英語：DC Universe）是指以DC漫畫公司旗下漫畫（但不是全部，如：「守望者」要直到《DC宇宙重生》才正式加入DC宇宙一員）所組成的統一的世界觀，
      其中包括漫畫中人物（超人、蝙蝠俠、綠光戰警、神力女超人及閃電俠等）、宇宙、神靈（上帝、新神等）、歷史走向、物理規律等。<br/>
      在上世紀50年代，DC漫畫公司收購了許多漫畫公司（如驚奇隊長原本就並非屬於DC漫畫），為了使得不同系列的漫畫在設定上不產生邏輯上的衝突，
      DC漫畫公司提出了平行宇宙的概念。但是隨著時間的推移，各種平行宇宙數目逐漸增多，漫畫人物及其設定產生混亂，DC漫畫公司藉助一起大事件：
      無限地球危機，對整個DC宇宙設定進行重新修改，平行世界被消除、除了少部分來自不同世界的英雄以原本的身分留在唯一的宇宙－新地球（英語：New Earth）外大多數的超級英雄們或多或少在背景設定產生了一定的更改。
      而有些白銀時代的超級英雄（如美國正義會社），則以老前輩的身分登場於新地球。
      <br/>後又推出一個名為52的大事件, 其結果是重新產生52個平行宇宙。不過正史世界依然是新地球。
      在2011年的大事件《閃點》過後，DC宇宙由於被曼哈頓博士改寫了正義會社的存在導致超人起源被改變，最終再次導致宇宙重啟，正史世界被主世界（英語：Prime Earth）取代，至此貫穿新52計畫和重生計畫的「新52宇宙」開啟。
      2020年1月《末日警鐘》第12刊中，曼哈頓博士最終決定修復閃點時犯下的錯誤，並修復了超人的起源。至此所以DC宇宙的被全面合併為一條時間線。</p>
      <p><i>DC的處理手法是較接近單一時間線，即穿越時空的行為會導致歷史有變動，漫畫中的平衡世界也存在著聯繫，如A世界的人只要找到方法可以出入B世界。</i></p>
    
    <hr>

    <span id="marvel"><h2>Marvel簡介</h2>
    <p>
      漫威出版公司（Marvel Publishing, Inc.，舊譯驚奇漫畫），普遍稱為漫威漫畫（Marvel Comics），是一家美國的漫畫公司，由漫威娛樂（Marvel Entertainment, Inc.）所持有。自2008年起，漫威娛樂的子公司漫威工作室（英語：Marvel Studios）開始拍攝漫威電影宇宙系列，
      將漫畫中的故事再次搬上螢幕；2009年漫威工作室成為華特迪士尼影業集團（Walt Disney Studios）的子公司。
      <br/>
      1990年代漫威的經營遇到危機，他們只好把旗下最受歡迎角色如蜘蛛人、X戰警、驚奇四超人等電影版權一一的賣給別家片商。
      直到2008年漫威決定開始拍片，從他們剩下的最大B咖角色鋼鐵人開始，小勞勃道尼，以整個漫畫宇宙觀的角度開始拍攝。後來不但成功了，還開啟了超級英雄的黃金十年。
      2017年12月，漫威影業所屬華特迪士尼公司以524億美元收購福斯集團旗下部分產權，包括由21世紀福斯所擁有的X戰警、驚奇4超人等系列版權，也一併收回華特迪士尼公司旗下漫威影業。
      美國時間2017年12月14日，華特迪士尼公司宣布X戰警、死侍、驚奇4超人等角色，將正式回歸漫威電影宇宙，但是否會與復仇者聯盟合併為一個大宇宙，目前還不得而知。
    </p>

    <h2>Marvel宇宙</h2>
    <p>漫威絕大部分的漫畫作品，主要的故事場景都發生在Earth-616，
      也就是漫威的主流宇宙；此外，還有眾多所謂的平行宇宙的存在，例如Earth-1610（終極宇宙）和Earth-2149（喪屍宇宙）。
      而在這些宇宙之上，還有被稱為多元宇宙 (Multiverse) 以及更大的全能宇宙 (Omniverse) 等的存在。<br/>
      目前漫威還將還將宇宙分成四個階段&mdash;&mdash;
      <li>第一階段：鋼鐵人(2008年)&mdash;復仇者聯盟(2012年)</li>
      <li>第二階段：鋼鐵人3(2013年)&mdash;蟻人(2015年)</li>
      <li>第三階段：美國隊長・英雄內戰(2016年)&mdash;蜘蛛人・離家日(2019年)</li>
      以上三個階段共23電影合稱【無限傳奇】系列，第四階段預計將由各人電影《黑寡婦》開啟。

    </span>
  </div>
</div>

</body>
</div>
</template>

<script>
</script>

<style>

body{
  display: flex;
  flex-direction: column;
  margin: 0px;
  padding: 0px 5px;
  background-color: black;
  height: 100%;
}

header{
  width: 100%;
  height: 3em;
  color: white;
  font-size: 1.8em;
  font-family: Rotobo;
  border-radius: 5px;
  display: flex;
  align-items: center;
  justify-content: center;
}

img{
  width: 5em;
  border-radius: 5px;
}

ul li{
  list-style-type: none;
}


.navbar .first{
  background-color: lightblue; 
  width: 100%;
  display: flex;
  justify-content: space-between;
  padding: 0px;
  margin-top: 5px;
  border-radius: 5px;
}

.navbar .first a{
  color: white;
  display: block;
  padding: 10px 20px;
  font-size: 1.1em;
  text-decoration: none;
}

.navbar .first > li{
  position: relative;
}

.navbar .second{
  position: absolute;
  font-size: 1em;
  padding: 0px;
  top: 100%;
  width: 100%;
  display: none;
  background-color: lightblue;
}

.navbar .first li:hover > a{
  background-color: #6495ED;
  border-radius: 5px;
}

.navbar li:hover > .second{
  display: block;
}

input{
  height: 1.5em;
  align-self: center;
  border: none;
  border-radius: 5px;
  background-color: #E0FFFF;
  margin-right: 5px;
  caret-color: 	#FFBF00;
  outline: none;
}

input:focus{
 border-style: solid 5px;
 border-color: #03a9f4;
 box-shadow: 0 0 10px #03a9f4;
}

.text{
  display: flex;
  flex-direction: row;
}

.article{
  color: white;
  width: 100%;
  margin-inline-start: 5%;
  margin-inline-end: 5%;
  line-height: 30px;
}

.sidebar{
  width: 300px;
  border-right: 1px solid white;
  display: flex;
}

.sidebar ul{
  list-style-type: none;
  margin: 0px;
}

.sidebar img{
  font-size: 6px;
  padding: 15px 10px 0px 0px;
}

.sidebar .sidefirst a{
  color: white;
  line-height: 2.5em;
  text-decoration: none;
}

img[alt*="deadpool"]{
  position: fixed;
  right: 0%;
  bottom: 0%;
  }

img[alt*="spiderman"]{
  position: fixed;
  bottom: 0%;
}

hr{
  border: 1px dashed khaki;
}

</style>
