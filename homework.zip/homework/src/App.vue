<template>
<div class="main">
    <div class="freenote">
        <h2 class="free">Freenote .</h2>
        <div class="new">
            <i class="fa fa-plus-circle plus"></i>
            <h4 class="newnote">新增筆記</h4></div>
       <div class="alltag">
            <i class="fa fa-file-text first"></i>
            <p class="all">所有筆記</p>
            <i class="fa fa-star iconnote"></i>
            <p class="tag">捷徑</P>
            <i class="fa fa-tag icontest"></i>
            <p class="tag">標籤</p>
            <i class="fa fa-calendar iconnote"></i>
            <p class="tag">月曆</p>
            <i class="fa fa-user iconnote"></i>
            <p class="tag">與我共用</p>
            <i class="fa fa-trash iconnote"></i>
            <p class="tag">垃圾桶</p>
        </div>
        
        <p class="mode">模式</p>
        <i class="fa fa-certificate iconmode1"></i>
        <i class="fa fa-moon-o iconmode2"></i>
        <div class="test2">
        <img src="./image/miso.png" class="miso">
        <p class="miso2">Miso</p>
        <i class="fa fa-chevron-down qqq"></i>
        </div> 
    
    </div>
    <div class="note">
        <div class="search">
            <img src="./image/search_24px.svg" class="icon"> 
            <input type="text" placeholder="搜尋您的筆記" class="search2" />
        </div>
        <div class="select">
            <p class="allnote">所有筆記</p>
            <i class="fa fa-chevron-down www"></i>
            <i class="fa fa-th iconform"></i>
        </div>
            <hr width="400px" color="#E6E6E6" align="cener">
        <div class="square">
            <h3 class="kk">無標題</h3>
            <hr width="250px" color="#E6E6E6" align="cener">
            <p class="date">2019/9/7</p>
        </div>
    </div>
    <div>
    <div class="vvv">
        <div class="line">
        <p class="arial">Arial</p> 
        <i class="fa fa-angle-down rrr"></i>
        <p class="fff">14</p>
        <i class="fa fa-angle-down rrr"></i>
        <i class="fa fa-bold BBB"></i>
        <i class="fa fa-italic iii"></i>
        <i class="fa fa-underline uuu"></i>
        <i class="fa fa-indent yyy"></i>
        <i class="fa fa-outdent ooo"></i>
        <i class="fa fa-align-left sss"></i>
        <i class="fa fa-angle-down rrr"></i>
        <i class="fa fa-align-justify zzz"></i>
        <i class="fa fa-angle-down rrr"></i>
        <i class="fa fa-list-ul xxx"></i>
        <i class="fa fa-link lll"></i>
        <i class="fa fa-image mmm"></i>
        <i class="fa fa-paperclip jjj"></i>
        <hr width="500px" color="#E6E6E6" align="left">
        </div>  

        <p class="none">無標題</p> 
        <div class="addplus"><p class="word">Add +</p></div>
        <div class="write">請寫下內容</div>
        <div class="lastplus">
        <i class="fa fa-file doc"></i>
        <p class="upload">上傳檔案、圖片、音檔</p>
        <p class="click"><u>點擊上傳檔案</u></p>
        <i class="fa fa-plus qwe"></i>
        </div>
    </div>
    </div>
</div>
</template>

<script>

</script>


<style>

.main{
    width: 100%;
    height: 100%;
}

.freenote{
    width:256px;
    height:850px;
    background-color:#2F419B;
    float:left;
}

    .free{
        font-size: 22px;
        font-family: Myriad Pro,Semibold;
        color: #FFFFFF;
        padding-top: 54px;
        padding-left: 54px;
        margin: 0px;
        display: inline-block;
    }

    .new{
        width: 190px;
        height: 48px;
        background-color: #FFFFFF;
        border-radius: 5px;
        margin-top: 33px;
        margin-left: 33px;
        margin-right: 33px;
    }

        .plus{color: #2F419B;
            font-size:26px;
            padding-top: 11px;
            padding-left: 30px;
        }

        .newnote{
            color: #2F419B;
            font-size: 18px;
            margin: 0px;
            padding: 11px 46px 11px 16px;
            float: right;
        }

    .alltag{
        margin-left: 30px;
    }

    .tag, .all, .first , .iconnote, .icontest, .mode, .iconmode1, .iconmode2, .miso2, .qqq
    {color: #FFFFFF;}

        .tag{
            font-family: Helvetica Neue;
            font-weight: lighter;
            font-size: 16px;
            padding-left: 11.34px;
            padding-top: 17px;
            margin-left: 40px;
        }

        .all{
            font-family: Helvetica Neue;
            font-weight: lighter;
            font-size: 16px;
            padding-top: 36px;
            padding-left: 11.34px;
            margin-left: 40px;
        } 

        .first{
            float: left;
            padding-top: 36px;
            padding-left: 25px;
        } 

        .iconnote{
            float: left;
            padding-left: 25px;
            padding-top: 20.11px;
        }
        
        .icontest{
            float: left;
            transform: rotate(45deg);
            padding-left: 34px;
            padding-top: 11px;
        }

    .mode{
        font-family: Helvetica Neue;
        font-weight: lighter;
        font-size: 16px;
        padding-left: 54px;
        margin-top: 200px;
        float: left;
    }

    .iconmode1{
        font-size: 26px;
        margin-left: 20px;
        margin-top: 198px;
        float: left;
    }

    .iconmode2{
        font-size: 26px;
        margin-left: 15px;
        margin-top: 198px;
        float: left;
    }

    .test2{
        width: 142px;
        height:35px;
        margin-top: 260px;
        margin-left: 54px;
    }

        .miso{
            width: 35px;
            height: 35px;
            padding-top: 0px;
            padding-right: 0px;
            float: left;
        }

        .miso2{
            font-family: Helvetica Neue;
            font-weight: lighter;
            font-size: 18px;
            padding-top: 7px;
            padding-left: 10px;
            margin: 0px;
            float: left;
        }

        .qqq{
            font-size: 12px;
            padding-left: 15px;
            padding-top: 12px;
        }
    



        .search .icon{
            width: 21px;
            height: 45px;
            border: none;
            padding-left: 20.6px;
            float: left;
        }

        .search .search2{
            width: 233px;
            height: 43px;
            border: none;
            background-color: #E6E6E6;
            padding-left: 12px;
        }

    .select{
        width: 290px;
        height: 42px;
        margin-top: 116px;
        margin-left: 32px;
    }

        .allnote{
            font-family: Helvetica Neue;
            font-weight: bold;
            color: #555555;
            display: inline;
        }

        .www{
            padding-left: 12px;
            color: #555555;
            font-size: 12px;
            display: inline;
        }
        
        .iconform{
            color: #555555;
            font-size: 13px;
            padding-left: 186px;
            margin: 0px;
            display: inline;
        }

    .square{ 
        width: 290px;
        height: 255px;
        background-color: #FFFFFF;
        position: relative;
        background: linear-gradient(-150deg, transparent 1.5em, #FFFFFF 0);
        border-radius: .5em;
        margin-left: 32px;
        margin-top: 32px;
        margin-right: 33px;
    }

    .square::before {
        content: '';
        position: absolute;
        top: 0;
        right: 0;
        background: linear-gradient(to left bottom, transparent 50%,  rgba(0,0,0,.2) 0,rgba(0,0,0,.2)) no-repeat 100% 0;
        width: 1.73em;
        height: 3em;
        transform: translateY(-1.3em) rotate(-30deg);
        transform-origin: bottom right;
        border-bottom-left-radius: inherit;
        box-shadow: -.2em .2em .3em -.1em rgba(0,0,0,.15);
    }


    .kk{
        color: #555555;
        padding-top: 35px;
        padding-left: 23px;
        margin: 0px;
    }

    .date{
        color: #666666;
        font-size: 15px;
        padding-left: 206px;
        padding-right: 26px;
        padding-top: 137.5px;
    }

.vvv{
    width: 650px;
    height:850px;
    background-color: #FFFFFF;
    float: left;
    margin-bottom: 20px;
}

    .line{
        width: 567px;
        height: 24px;
        margin: 52px 56px 10px 46px;
    }


        .arial{
            font-size: 18px;
            font-family: Helvetica Neue;
            font-weight: medium;
            color: #666666;
            margin: 0px;
            display: inline;
        }
        
        .rrr{
            font-size: 14px;
            color: #A3A3A3;
            display: inline;
            padding-left: 4.69px;
            padding-bottom: 10px;
        }

        .fff{
            font-size: 18px;
            font-family: Helvetica Neue;
            font-weight: bold;
            color: #666666;
            display: inline;
            padding-left: 20px;
            margin: 0px;
        }

        .BBB, .iii, .uuu, .yyy, .ooo, .sss, .zzz, .xxx, .lll, .mmm, .jjj
        {
            font-size: 16px;
            color: #666666; 
            display: inline;
        }

        .BBB{
            font-weight: bold;
            padding-left: 21px;
            padding-bottom: 10px;
        }

        .iii, .uuu, ooo{
            padding-left: 14px;
        }
        
        .yyy{
            padding-left: 21px;
        }
        
        
        .sss, .zzz, .xxx, .lll{
            padding-left: 20.35px;
        }


        .mmm, .jjj, .ooo{
            padding-left: 9.6px;
        }


        .word{
            color:#A3A3A3; 
            font-size: 14px;
            padding: 7px 2px 3px 19px;
            margin: 0px;
            display: inline;
        }

        .addplus{
            width: 75px;
            height: 25px;
            border: 1px;
            border-color: #C7C7C7;
            border-style: dashed;
            border-radius: 3px;
            margin-left: 46px;
        }

        .none{
            font-size: 21px;
            color: #A3A3A3;
            padding-top: 35.5px;
            padding-left: 46px;
        }

        .write{
            width: 580px;
            height: 142px;
            font-size: 16px;
            color: #666666;
            margin-top: 30px;
            margin-left: 46px;
        }

        .lastplus{
            width:580px;
            height: 55px;
            border: 1px;
            border-color: #C7C7C7;
            border-style: dashed;
            border-radius: 5px;
            margin-left: 46px;
            margin-top: 233px;
        }

            .doc{
                font-size: 18px;
                color: #A3A3A3;
                margin: 19px 11px 18px 31px;
                display: inline-block;
            }

            .upload{
                font-size: 16px;
                color: #A3A3A3;
                display: inline;
            }
            
            .click{
                font-size: 16px;
                color: #A3A3A3;
                padding-left: 16px;
                display: inline;
            }

            .qwe{
                font-size: 16px;
                color: #A3A3A3;
                float: right;
                padding-top: 17px;
                padding-right: 18px;
            }

</style>
